/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicfinal;

/**
 *
 * @author duran
 */
public class MagicFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        inicio init = new inicio();
        init.setBounds(0, 0, 300, 400);
        init.setVisible(true);
        init.setLocationRelativeTo(null);
        init.setResizable(false);
        
        
       
       
    
}
}
