
package magicfinal;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import paquete1.cuentaIngresar;

/**
 *
 * @author duran
 */
public class cuentaLogin extends JFrame implements MouseListener{
    JPanel panelCuentLogin;
    JButton botonNuevoUsuario,BotornUsuarioRegistrado;
    ImageIcon fondo;
    JLabel fondoo;
    
    public cuentaLogin() {
        this.setTitle("TypingManiac");
        initComponents();
    }
    
    
    public void initComponents(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //-------------> agregando panel
        fondo = new ImageIcon("pantallalogin2.jpg");
        panelCuentLogin = new JPanel();
        panelCuentLogin.setLayout(null);
        panelCuentLogin.setBounds(0, 0, 300, 300);
        panelCuentLogin.setBackground(Color.green);
        this.getContentPane().add(panelCuentLogin);
        
        //JLabel fondo
        fondoo = new JLabel();
        fondoo.setIcon(fondo);
        fondoo.setBounds(0,0,300,300);
        panelCuentLogin.add(fondoo);
        
        //-------------> agregando botones
        botonNuevoUsuario = new JButton("CREAR CUENTA");
        botonNuevoUsuario.setBounds(40,60,200,40);
        botonNuevoUsuario.setBackground(Color.black);
        botonNuevoUsuario.setForeground(Color.yellow);
        botonNuevoUsuario.setFont(new Font("Arial", Font.PLAIN, 20));
        fondoo.add(botonNuevoUsuario);
        
        BotornUsuarioRegistrado = new JButton("INGRESAR");
        BotornUsuarioRegistrado.setBackground(Color.black);
        BotornUsuarioRegistrado.setForeground(Color.yellow);
        BotornUsuarioRegistrado.setBounds(40,160,200,40);
        BotornUsuarioRegistrado.setFont(new Font("Arial", Font.PLAIN, 20));
        fondoo.add(BotornUsuarioRegistrado);
        
        //agregando eventos a los botones
        botonNuevoUsuario.addMouseListener(this);
        BotornUsuarioRegistrado.addMouseListener(this);
        
    }    

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == botonNuevoUsuario){
            LoginNuevoUsuario newuser = new LoginNuevoUsuario();
            newuser.setBounds(0,0,300,450);
            newuser.setVisible(true);
            newuser.setLocationRelativeTo(null);
            newuser.setResizable(false);
            this.setVisible(false);
            
            //cerrando pestaña actual
            this.setVisible(false);
        }else if( e.getSource() == BotornUsuarioRegistrado){
            cuentaIngresar ingresar = new cuentaIngresar();
            ingresar.setBounds(0,0,300,450);
            ingresar.setVisible(true);
            ingresar.setLocationRelativeTo(null);
            ingresar.setResizable(false);
            this.setVisible(false);
        }
       
    }

    @Override
    public void mousePressed(MouseEvent e) {
       
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
       
    }
    
}
