/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author duran
 */


package magicfinal;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingConstants;


/**
 *
 * @author duran
 */

public class pantallaNivel2 extends JFrame implements KeyListener{
    JPanel panelJuego1, panelBonus,panelPalabrasCayendo[] = new JPanel[10],panelPalabrasCayendo2[] = new JPanel[5], panelFondoBonus;
    JLabel labelPalabras[] = new JLabel[10],labelPalabras2[] = new JLabel[5],bonusStop,nameScore,labeLInicio,fondoo,personajee,bonusDisponibles,bonusDisponibles1;
    int auxcont=0,contadorPalabra = 0, contadorPalabrasCorrectas = 0,i=5,arreglo[] = new int[10],arreglo2[] = new int[5],v = 0,v2=0,velocidad = 800,velocidad2 = 1000,parar = 0;
    JTextField texto,textoScore;
    String palabraActual;
    ImageIcon fondo,personaje;
    Icon icono,icono1;
    boolean isBonus = false,ocupado = false,isActive = false,startGame = false,isBonusCorrect = false;
    
    String linea;
    String[] palabras2 ={"mamalona","leones","altiro","nomofobia","caracas"};
    String[] palabras ={"closificar","pleonasmo","estulticia","fementido","suntuoso","fantoche","gigil","impio","trivial","cardenales"};
    Sonido sonido2 = new Sonido();
    Sonido sonido3 = new Sonido();
    Sonido sonido4 = new Sonido();
    Sonido sonido5 = new Sonido();
    //constructor
    public pantallaNivel2() {
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        fondo = new ImageIcon("fondo2.jpg");
        personaje = new ImageIcon("jugadornivel2.png");
        
        panelJuego1 = new JPanel();
        panelJuego1.setLayout(null);
        panelJuego1.setBounds(0, 0, 1000,900);
        panelJuego1.setOpaque(false);
        this.getContentPane().add(panelJuego1);
        fondoo = new JLabel();   
         icono = new ImageIcon(fondo.getImage().getScaledInstance(panelJuego1.getWidth(),panelJuego1.getHeight(), Image.SCALE_DEFAULT));
        fondoo.setOpaque(false);
         fondoo.setBounds(0,0,920,700);
        panelJuego1.add(fondoo);
        //cuenta regresiva
        labeLInicio = new JLabel();
        labeLInicio.setBounds(420, 300, 200, 100);
        labeLInicio.setFont(new Font("Serif", Font.PLAIN, 50));
        fondoo.add(labeLInicio);
        sonido2.ReproducirSonido("sonidos/pacma.wav");
        timerContador.start();
 
          //  System.out.print("estara activo?"+ startGame);
            
            // timer.start();    
        
         
    }
    //iniciando los componentes del juego
    public void initComponents() throws FileNotFoundException{
        generarNumeroAleatorios(10,10);
        generarNumeroAleatorios2(5,5);
        fondo = new ImageIcon("fondo2.jpg");
        personaje = new ImageIcon("jugadornivel2.PNG");
        //bonus points
        bonusStop= new JLabel("arcade");
        bonusStop.setForeground(Color.blue);
        bonusStop.setBounds(190, 10, 120, 20);
        bonusStop.setVisible(false);
        fondoo.add(bonusStop);
        //panel de fondo del bonus
        panelFondoBonus = new JPanel();
        panelFondoBonus.setBounds(190, 10, 120, 20);
        panelFondoBonus.setVisible(false);
        panelFondoBonus.setBackground(Color.yellow);
        fondoo.add(panelFondoBonus);
        
        
        //cuenta regresiva
        panelJuego1 = new JPanel();
        panelJuego1.setLayout(null);
        icono = new ImageIcon(fondo.getImage().getScaledInstance(this.getWidth(),this.getHeight(),Image.SCALE_DEFAULT));

        this.getContentPane().add(panelJuego1);
        //Label fondo
        fondoo = new JLabel();
        fondoo.setIcon(icono);
        //fondoo.setBounds(0,0,1000,900);
        fondoo.setBounds(0,0,this.getWidth(),this.getHeight());
        panelJuego1.add(fondoo);
        
        //Label personaje
        personajee = new JLabel();
        icono1 = new ImageIcon(personaje.getImage().getScaledInstance(320,300,Image.SCALE_SMOOTH));
        personajee.setIcon(icono1);
        personajee.setBounds(320,370,500,300);
        fondoo.add(personajee);
        //textField
       texto = new JTextField();
       texto.setBounds(400, 640, 100, 20);
       fondoo.add(texto);
       texto.addKeyListener(this);
       
       //el Scoreee
       nameScore = new JLabel("Score: ");
       nameScore.setFont(new Font("Times New Roman", Font.PLAIN, 16));
       nameScore.setBounds(850, 400, 50, 20);
       fondoo.add(nameScore);
       
       textoScore = new JTextField();
       textoScore.setBounds(850, 420, 50, 20);
       textoScore.setEditable(false);
       textoScore.setBackground(Color.LIGHT_GRAY);
       fondoo.add(textoScore);
       //bonus disponibles
       panelBonus = new JPanel();
       panelBonus.setBounds(850, 300, 60, 50);
       panelBonus.setBackground(Color.LIGHT_GRAY);
       fondoo.add(panelBonus);
       bonusDisponibles = new JLabel("BONUS :");
       bonusDisponibles.setFont(new Font("Times New Roman", Font.PLAIN, 16));
       bonusDisponibles.setBounds(850, 300, 50, 20);
       
       panelBonus.add(bonusDisponibles);
       //bonus
       bonusDisponibles1 = new JLabel("pare");
       bonusDisponibles1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
       bonusDisponibles1.setBounds(850, 320, 50, 20);
       
       panelBonus.add(bonusDisponibles1);
       //cuenta regresiva
       labeLInicio = new JLabel();
       labeLInicio.setBounds(200, 200, 200, 100);
       labeLInicio.setFont(new Font("Serif", Font.PLAIN, 50));
       fondoo.add(labeLInicio);
        //iniciando y aocmodandl loss label y las palabras en el juego
        for(int i = 0 ;i<labelPalabras.length;i++){
            panelPalabrasCayendo[i] = new JPanel();
            panelPalabrasCayendo[i].setBackground(Color.cyan);
            panelPalabrasCayendo[i].setBounds(i*90, 10, 80, 20);
            panelPalabrasCayendo[i].setVisible(false);
            labelPalabras[i] = new JLabel(palabras[i]);
            labelPalabras[i].setBounds(i*90, 10, 80, 20);
            labelPalabras[i].setForeground(Color.black);
            labelPalabras[i].setVisible(false);
            labelPalabras[i].setFont(new Font("Times New Roman", Font.PLAIN, 17));
            labelPalabras[i].setHorizontalAlignment(SwingConstants.CENTER);
            fondoo.add(labelPalabras[i]);
            
            fondoo.add(panelPalabrasCayendo[i]);
            
        }
        //para la segunda paalbra
        for(int j = 0 ; j<labelPalabras2.length;j++){
            panelPalabrasCayendo2[j] = new JPanel();
            panelPalabrasCayendo2[j].setBackground(Color.cyan);
            panelPalabrasCayendo2[j].setBounds(j*90, 10, 80, 20);
            panelPalabrasCayendo2[j].setVisible(false);
            labelPalabras2[j] = new JLabel(palabras2[j]);
            labelPalabras2[j].setBounds(j*90, 10, 80, 20);
            labelPalabras2[j].setForeground(Color.black);
            labelPalabras2[j].setVisible(false);
            labelPalabras2[j].setFont(new Font("Times New Roman", Font.PLAIN, 17));
            labelPalabras2[j].setHorizontalAlignment(SwingConstants.CENTER);
            fondoo.add(labelPalabras2[j]);
            
            fondoo.add(panelPalabrasCayendo2[j]);
        }
        
       //comenzando el timer de nuemeros aleatorios
       timer.start();
       
       File archivo = new File ("puntaje.txt");
       FileReader fr = new FileReader (archivo);
       BufferedReader br = new BufferedReader(fr);
       
       try{
           
           
         linea=br.readLine();
            System.out.println(linea);
            
       }catch(Exception e){
         e.printStackTrace();
      }
       
       auxcont = Integer.parseInt(linea);
       System.out.println("numero: "+ auxcont);
       contadorPalabra = auxcont;
       
       
       
       textoScore.setText(String.valueOf(contadorPalabra));
    }
    
   int tiempo = 0;
   int tiempo2 = 0;
    Timer timer = new Timer(velocidad2,
            new ActionListener(){
        
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Tu Codigo
                    
                    if( parar == 0) {
                        
                     
                         if(v != 10 ){
                            panelPalabrasCayendo[arreglo[v]].setVisible(true);
                            labelPalabras[arreglo[v]].setVisible(true);
                            panelPalabrasCayendo[arreglo[v]].setLocation(panelPalabrasCayendo[arreglo[v]].getX(), panelPalabrasCayendo[arreglo[v]].getY()+50);
                            labelPalabras[arreglo[v]].setLocation(labelPalabras[arreglo[v]].getX(), labelPalabras[arreglo[v]].getY()+50);
                            // System.out.println("y0: "+labelPalabras[arreglo[v]].getY());
                            // System.out.println("y "+(v+1)+"::"+labelPalabras[arreglo[v]].getY());                   
                            palabraActual = labelPalabras[arreglo[v]].getText().toString();                             
                                if(labelPalabras[arreglo[v]].getY() == 610 || isActive ==true || panelPalabrasCayendo[arreglo[v]].getY() == 610){
                                   System.out.println("troleo hermano");  
                                   panelPalabrasCayendo[arreglo[v]].setVisible(false);
                                   labelPalabras[arreglo[v]].setVisible(false);
                                   v ++; 
                                   isActive = false;
                                }   
                                if(v ==5){
                                isBonus=true;
                                     
                            }
                        }

                        if(v ==10){
                            terminar();
                            
                        }
                        if(isBonus ==true){
                       panelFondoBonus.setVisible(true);
                       bonusStop.setVisible(true);
                       panelFondoBonus.setLocation(panelFondoBonus.getX(),panelFondoBonus.getY()+50);
                                bonusStop.setLocation(bonusStop.getX(),bonusStop.getY()+50);
                                
                                if(bonusStop.getY()==610 || isBonusCorrect==true ||panelFondoBonus.getY()==610){
                                 bonusStop.setVisible(false);
                                 panelFondoBonus.setVisible(false);
                                 isBonus=false; }
                    }
                        
                        
                    }else {
                        tiempo++;
                        if(tiempo == 5){
                            parar = 0;
                            ocupado = false;
                        }
                    }
                }  

                    
            });
    
    
 //ceunta regresiva del juego   
   Timer timerContador = new Timer(1000,
            new ActionListener(){
        
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Tu Codigo
                   
                    
                    if(i!=0){
                        
                        labeLInicio.setText(String.valueOf(i-1));
                        i--;
                        
                    }
                    
                    if(i==0){
                         labeLInicio.setText("READY");
                       i--;
                     
                    }
                   
                    if(i==-2){
                        labeLInicio.setVisible(false);
                        startGame =true;
                        terminarContador();
                        try {                
                            componenetes(startGame);
                        } catch (FileNotFoundException ex) {
                            Logger.getLogger(pantallaNivel2.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }           
                }

            });

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    //UANDO PRESIONEMOS LA TECLA ENTER HACER LAS RESPECTIVAS VALIDACIONES
    @Override
    public void keyPressed(KeyEvent e) {
        //System.out.println("presiono la tecla: "+e.getKeyCode());
        
        
        switch(e.getKeyCode()){
            case KeyEvent.VK_ENTER:{
                //caso deque sea igaul palabra
                    if(texto.getText().compareTo("pare") == 0  && ocupado == false){
                        sonido5.ReproducirSonido("sonidos/hongo.wav");
                        System.out.println("para el proceso");
                        texto.setText("");
                        bonusDisponibles1.setVisible(false);
                        parar = 1;
                        velocidad2 = 1000;
                        tiempo = 0;
                        ocupado = true;
                    }
                    else if(texto.getText().equalsIgnoreCase(palabraActual)){
                       
                            CorrectWords(); 
                    
                  }else if(texto.getText().equalsIgnoreCase("arcade")){
                        timer.stop();
                         String [] arreglo = {"seguir jugando","me gusta"};
                        int opcion = JOptionPane.showOptionDialog(null, "En el arcade original de Donkey Kong, Mario se llama Jumpman y es un carpintero, no un fontanero", "DATO CURIOSO", 0, JOptionPane.QUESTION_MESSAGE, null, arreglo, "seguir jugando");
                        
                        if(opcion == 0){
                            System.out.println("QUE SIGA EL JUEGO PERRO");
                            timer.restart();
                        }
                      
                      
                      texto.setText("");
                      isBonusCorrect = true;
                      timer.restart();
                  }else{
                       IncorrectWords();
                  }
                     
                break;
            }
        }              
                
            
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    
   //CONFIRMAR SI LA PALABRA ESTA BIEN ESCRITA 
    public void CorrectWords(){
        //System.out.println("la palabra es correcta");
        sonido3.ReproducirSonido("sonidos/moneda.wav");
        texto.setText("");
        contadorPalabra = contadorPalabra+50;
        textoScore.setText(String.valueOf(contadorPalabra));
        isActive = true;
        contadorPalabrasCorrectas++;
    }
    //PALABRAS INCORRECTAS
    public void IncorrectWords(){
        sonido4.ReproducirSonido("sonidos/tubo.wav");
        texto.setText("");
        contadorPalabra = contadorPalabra-20;
        textoScore.setText(String.valueOf(contadorPalabra));
       // System.out.println("perdio puntos SAPO");
    }
    //generamos numeros aleatorios
    public void generarNumeroAleatorios(int cantidad,int rango){
        int i = 0;
                     
                    //del uno al 10 quiero que me genere
                     
                     arreglo[i] = (int)(Math.random()*rango);
                     for(i=1;i<cantidad;i++){
                        arreglo[i] = (int)(Math.random()*rango);
                        for (int j = 0; j < i; j++) {
                            if(arreglo[i] == arreglo[j]){
                                i--;
                            }
                        }
                    }
                     for (int j = 0; j < arreglo.length; j++) {
                         System.out.println("aleatorio"+ arreglo[j]);       
                    }    
    }
    //GENERAMOS NUMEROS ALEATORIOS PARA EL OTRO VECTOR DE PALABRAS
    public void generarNumeroAleatorios2(int cantidad,int rango){
        int i = 0;
                     
                    //del uno al 10 quiero que me genere
                     
                     arreglo2[i] = (int)(Math.random()*rango);
                     for(i=1;i<cantidad;i++){
                        arreglo2[i] = (int)(Math.random()*rango);
                        for (int j = 0; j < i; j++) {
                            if(arreglo2[i] == arreglo2[j]){
                                i--;
                            }
                        }
                    }
                     for (int j = 0; j < arreglo2.length; j++) {
                         System.out.println("aleatorio2:"+ arreglo2[j]);       
                    }    
    }
    //detonador del timer
     public void terminar(){
        timer.stop();
        timer2.start();
        
    }
     //EL STOP DE LAS SEGUNDAS PAALBRAS
     public void terminar2(){
        timer2.stop();
        
        if(textoScore.getText().toString().equalsIgnoreCase("")){
            JOptionPane.showMessageDialog(null, "puntaje total: 0 ");
            
        }else{
            JOptionPane.showMessageDialog(null, "puntaje total: "+ textoScore.getText().toString());  
        }
       
                        if(contadorPalabrasCorrectas>=10){
                           JOptionPane.showMessageDialog(null, "HAZ PASADO AL SIGUIENTE NIVEL ,UNDE ACEPTAR");
                           pantallaNivel3  nivel3 = new pantallaNivel3();
                            this.setVisible(false);
                            nivel3.setVisible(true);
                            nivel3.setBounds(0, 0, 920, 700);
                            nivel3.setLocationRelativeTo(null);
                            nivel3.setResizable(false);
                            
                             try {
                              BufferedWriter bufer = new BufferedWriter (new FileWriter ("puntaje2.txt",true));
                              bufer.write(textoScore.getText());
                              bufer.close();
                             }catch (IOException e1){
                            JOptionPane.showMessageDialog(null,"Se ha presentado un problema en el registro","Error",2);
                };
                            
                                
                       
                                
                            
                            
                        }else{
                            sonido3.ReproducirSonido("sonidos/perdio.wav");
                            JOptionPane.showMessageDialog(null, "no haz alcanzado el limite de palabras,vuevle a intentarlo");
                            System.exit(0);
                        }
                        
    }
     public void terminarContador(){
         timerContador.stop();
     }
     //INICIANDO LOS COMPONENTES CUANDO SE ACABE LA CUENTA
     public void componenetes(boolean active) throws FileNotFoundException{
         if(active == true){
             System.out.println("es verdadero esta");
          
             initComponents();
                
             
         }
         
     }
     
     
     //timer para que caigan las sefundas palabras
     Timer timer2 = new Timer(velocidad2,
            new ActionListener(){
        
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Tu Codigo
                    
                    if( parar == 0) {
                        if(velocidad2 == 10000){
                            System.out.println("tiempo"+velocidad2);
                            tiempo2++;
                            if(tiempo2 >= 5){
                                tiempo2 = 0;
                                ocupado = false;
                                velocidad2 = 1000;
                                timer2.stop();
                                timer2.restart();
                            }
                        }
                     
                         if(v2 != 5 ){
                            panelPalabrasCayendo2[arreglo2[v2]].setVisible(true);
                            labelPalabras2[arreglo2[v2]].setVisible(true);
                            panelPalabrasCayendo2[arreglo2[v2]].setLocation(panelPalabrasCayendo2[arreglo2[v2]].getX(), panelPalabrasCayendo2[arreglo2[v2]].getY()+50);
                            labelPalabras2[arreglo2[v2]].setLocation(labelPalabras2[arreglo2[v2]].getX(), labelPalabras2[arreglo2[v2]].getY()+50);
                            // System.out.println("y0: "+labelPalabras[arreglo[v]].getY());
                            // System.out.println("y "+(v+1)+"::"+labelPalabras[arreglo[v]].getY());                   
                            palabraActual = labelPalabras2[arreglo2[v2]].getText().toString();                             
                                if(labelPalabras2[arreglo2[v2]].getY() == 610 || isActive ==true || panelPalabrasCayendo2[arreglo2[v2]].getY() == 610){
                                   System.out.println("troleo hermano");  
                                   panelPalabrasCayendo2[arreglo2[v2]].setVisible(false);
                                   labelPalabras2[arreglo2[v2]].setVisible(false);
                                   v2 ++; 
                                   isActive = false;
                                }   
  
                            }
                        }

                        if(v2 ==5){
                            terminar2();
                            
                        }
                        else {
                        tiempo2++;
                        if(tiempo2 == 5){
                            parar = 0;
                            ocupado = false;
                        }
                    }
                }  

                    
            });
     
    
}

