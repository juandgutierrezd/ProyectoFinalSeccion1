
package paquete1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import magicfinal.pantallaNivel1;
import magicfinal.pantallaNivel2;
import magicfinal.pantallaNivel3;


/**
 *
 * @author duran
 */
public class cuentaIngresar extends JFrame implements MouseListener{
    JPanel panelCuentaIngresar;
    JLabel labelNombre;
    JComboBox comboNombres;
    JButton botonComenzar;
    ImageIcon fondo;
    JLabel fondoo;
    Icon icono;
    
    public cuentaIngresar() {
        this.setTitle("TypingManiac");
        initComponents();
    }
    
    
    public void initComponents(){
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //panel 
        fondo = new ImageIcon("pantallalogin3.jpg");
        panelCuentaIngresar = new JPanel();
        panelCuentaIngresar.setLayout(null);
        panelCuentaIngresar.setBounds(0, 0, 300, 450);
        panelCuentaIngresar.setBackground(Color.cyan);
        this.getContentPane().add(panelCuentaIngresar);
        
        
        //JLabel fondo
        
        fondoo = new JLabel();
        icono = new ImageIcon(fondo.getImage().getScaledInstance(panelCuentaIngresar.getWidth(),panelCuentaIngresar.getHeight(), Image.SCALE_DEFAULT));
        fondoo.setIcon(icono);
        fondo = new ImageIcon();
        fondoo.setBounds(0,0,300,450);
        panelCuentaIngresar.add(fondoo);
        
        //label nombre
        labelNombre  = new JLabel("Seleccione Nombre");
        labelNombre.setBounds(50, 80, 200, 60);
        labelNombre.setForeground(Color.white);
        labelNombre.setFont(new Font("arial", Font.PLAIN, 20));
        fondoo.add(labelNombre);
        
        
        //combo box
        comboNombres = new JComboBox();
        comboNombres.setBounds(40, 180, 200, 20);
        comboNombres.setBackground(Color.LIGHT_GRAY);
        comboNombres.addItem("");
        try {
            
            BufferedReader bufer = new BufferedReader (new FileReader ("usuarios.txt"));
            String cadena;
            String [] usuario;
            while ((cadena=bufer.readLine())!=null){
                
                usuario = cadena.split("-");
                
                comboNombres.addItem(usuario[0]);
                
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Se ha presentado un problema","Error",2);
            
        }
        
        fondoo.add(comboNombres);
        
        //botonIniciar
        botonComenzar = new JButton("Comenzar");
        botonComenzar.setBounds(40, 380, 200, 20);
        fondoo.add(botonComenzar);
        botonComenzar.addMouseListener(this);
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getSource() == botonComenzar){
            JOptionPane.showMessageDialog(null,"BIENVENIDO: "+comboNombres.getSelectedItem().toString());
            pantallaNivel1 nivel1 = new pantallaNivel1();
            this.setVisible(false);
            nivel1.setVisible(true);
            nivel1.setBounds(0, 0, 920, 700);
            nivel1.setLocationRelativeTo(null);
            nivel1.setResizable(false);
            
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
       
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }
    
    
}
